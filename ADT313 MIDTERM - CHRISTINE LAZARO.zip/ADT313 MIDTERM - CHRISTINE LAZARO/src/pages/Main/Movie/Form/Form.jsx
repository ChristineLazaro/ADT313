import axios from 'axios';
import { useCallback, useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './Form.css';

const Form = () => {
  const [query, setQuery] = useState('');
  const [searchedMovieList, setSearchedMovieList] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(undefined);
  const [movie, setMovie] = useState(undefined);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const { movieId } = useParams();
  const navigate = useNavigate();

  // Form fields state
  const [title, setTitle] = useState('');
  const [overview, setOverview] = useState('');
  const [popularity, setPopularity] = useState('');
  const [releaseDate, setReleaseDate] = useState('');
  const [voteAverage, setVoteAverage] = useState('');
  const [isFeatured, setIsFeatured] = useState(0); 
  const handleSearch = useCallback(async () => {
    try {
      const response = await axios.get(
        `https://api.themoviedb.org/3/search/movie?query=${query}&include_adult=false&language=en-US&page=${page}`,
        {
          headers: {
            Accept: 'application/json',
            Authorization:
              'Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI5YTdiNmUyNGJkNWRkNjhiNmE1ZWFjZjgyNWY3NGY5ZCIsIm5iZiI6MTcyOTI5NzI5Ny4wNzMzNTEsInN1YiI6IjY2MzhlZGM0MmZhZjRkMDEzMGM2NzM3NyIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.ZIX4EF2yAKl6NwhcmhZucxSQi1rJDZiGG80tDd6_9XI',
          },
        }
      );
      setSearchedMovieList(response.data.results);
      setTotalPages(response.data.total_pages);
    } catch (error) {
      console.error("Error fetching movies:", error);
      alert("Failed to fetch movies. Please try again later.");
    }
  }, [query, page]);

  const handleSelectMovie = (movie) => {
    setSelectedMovie(movie);
    setTitle(movie.original_title);
    setOverview(movie.overview);
    setPopularity(movie.popularity);
    setReleaseDate(movie.release_date);
    setVoteAverage(movie.vote_average);
  };

  const handleSave = async () => {
    try {
      const accessToken = localStorage.getItem('accessToken');
      if (!selectedMovie) {
        alert('Please search and select a movie.');
        return;
      }

      const data = {
        tmdbId: selectedMovie.id,
        title,
        overview,
        popularity,
        releaseDate,
        voteAverage,
        backdropPath: `https://image.tmdb.org/t/p/original/${selectedMovie.backdrop_path}`,
        posterPath: `https://image.tmdb.org/t/p/original/${selectedMovie.poster_path}`,
        isFeatured: isFeatured,
      };

      await axios.post('/movies', data, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      alert('Movie saved successfully!');
      navigate('/main/movies');
    } catch (error) {
      console.error("Error saving movie:", error);
      alert("Failed to save movie. Please try again.");
    }
  };

  const handleUpdate = async () => {
    try {
      const accessToken = localStorage.getItem('accessToken');
      const data = {
        title,
        overview,
        popularity,
        releaseDate,
        voteAverage,
        isFeatured: isFeatured, 
      };

      console.log("Updating movie with ID:", movieId); 
      console.log("Data being sent:", data); 

      await axios.patch(`/movies/${movieId}`, data, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      alert('Movie updated successfully!');
      navigate('/main/movies');
    } catch (error) {
      console.error("Error updating movie:", error);
      if (error.response) {
        console.log("Server Response:", error.response.data);
        alert(`Failed to update movie. Server response: ${error.response.data.message || "Unknown error"}`);
      } else {
        alert("Failed to update movie. Please try again.");
      }
    }
  };

  useEffect(() => {
    if (movieId) {
      axios.get(`/movies/${movieId}`).then((response) => {
        setMovie(response.data);
        setSelectedMovie({
          id: response.data.tmdbId,
          original_title: response.data.title,
          overview: response.data.overview,
          popularity: response.data.popularity,
          poster_path: response.data.posterPath,
          release_date: response.data.releaseDate,
          vote_average: response.data.voteAverage,
        });
        setTitle(response.data.title);
        setOverview(response.data.overview);
        setPopularity(response.data.popularity);
        setReleaseDate(response.data.releaseDate);
        setVoteAverage(response.data.voteAverage);
        setIsFeatured(response.data.isFeatured || 0); 
      }).catch(error => {
        console.error("Error fetching movie data:", error);
      });
    }
  }, [movieId]);

  const handlePageChange = (newPage) => {
    setPage(newPage);
  };

  return (
    <>
      <h1>{movieId ? 'Edit' : 'Create'} Movie</h1>

      {!movieId && (
        <>
          <div className="search-container">
            <label>
              Search Movie:
              <input type="text" onChange={(event) => setQuery(event.target.value)} />
            </label>
            <button type="button" onClick={handleSearch}>Search</button>
            <div className="searched-movie">
              {searchedMovieList.map((movie) => (
                <p key={movie.id} onClick={() => handleSelectMovie(movie)}>
                  {movie.original_title}
                </p>
              ))}
            </div>
            <div className="pagination">
              <button disabled={page <= 1} onClick={() => handlePageChange(page - 1)}>Previous</button>
              <span>Page {page} of {totalPages}</span>
              <button disabled={page >= totalPages} onClick={() => handlePageChange(page + 1)}>Next</button>
            </div>
          </div>
          <hr />
        </>
      )}

      <div className="container">
        <form>
          {selectedMovie && <img className="poster-image" src={`https://image.tmdb.org/t/p/original/${selectedMovie.poster_path}`} alt="Poster" />}
          <div className="field">
            Title:
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="field">
            Overview:
            <textarea rows={10} value={overview} onChange={(e) => setOverview(e.target.value)} />
          </div>
          <div className="field">
            Popularity:
            <input type="text" value={popularity} onChange={(e) => setPopularity(e.target.value)} />
          </div>
          <div className="field">
            Release Date:
            <input type="text" value={releaseDate} onChange={(e) => setReleaseDate(e.target.value)} />
          </div>
          <div className="field">
            Vote Average:
            <input type="text" value={voteAverage} onChange={(e) => setVoteAverage(e.target.value)} />
          </div>
          <button type="button" onClick={movieId ? handleUpdate : handleSave}>
            {movieId ? 'Update' : 'Save'}
          </button>
        </form>
      </div>
    </>
  );
};

export default Form;
