import { useReducer, useState } from 'react';
import data from './problem8mock_data.json';

const initialState = data;

const foodReducer = (state, action) => {
  switch (action.type) {
    case 'CREATE':
      return [...state, action.payload];
    case 'READ':
      return state.find((food) => food.food_name === action.payload);
    case 'UPDATE':
      return state.map((food) =>
        food.food_name === action.payload.food_name ? action.payload : food
      );
    case 'DELETE':
      return state.filter((food) => food.food_name !== action.payload);
    case 'CLEAR':
      return initialState;
    default:
      return state;
  }
};

export default function Problem8() {
  const [foods, dispatch] = useReducer(foodReducer, initialState);
  const [formValues, setFormValues] = useState({
    food_name: '',
    price: '',
    expiration_date: '',
    calories: ''
  });
  const [selected, setSelected] = useState(null);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues((prevValues) => ({
      ...prevValues,
      [name]: value
    }));
  };

  const handleSave = () => {
    if (selected) {
      dispatch({ type: 'UPDATE', payload: formValues });
    } else {
      dispatch({ type: 'CREATE', payload: formValues });
    }
    handleClear();
  };

  const handleEdit = (food) => {
    setSelected(food.food_name);
    setFormValues(food);
  };

  const handleDelete = (food_name) => {
    dispatch({ type: 'DELETE', payload: food_name });
    handleClear();
  };

  const handleClear = () => {
    setFormValues({ food_name: '', price: '', expiration_date: '', calories: '' });
    setSelected(null);
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            type='text'
            name='food_name'
            value={formValues.food_name}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            type='text'
            name='price'
            value={formValues.price}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            type='text'
            name='expiration_date'
            value={formValues.expiration_date}
            onChange={handleChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            type='text'
            name='calories'
            value={formValues.calories}
            onChange={handleChange}
          />
        </div>
        <button type='button' onClick={handleSave}>
          {selected ? 'Update' : 'Save'}
        </button>
        <button type='button' onClick={handleClear}>
          Clear
        </button>
      </div>

      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {foods.map((food) => (
              <tr key={food.food_name}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(food)}>
                    Edit
                  </button>
                  <button type='button' onClick={() => handleDelete(food.food_name)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
