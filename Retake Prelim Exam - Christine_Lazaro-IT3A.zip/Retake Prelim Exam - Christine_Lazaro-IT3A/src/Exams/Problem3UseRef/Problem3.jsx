import React, { useRef } from 'react';

function Problem3() {
  
  const input1 = useRef(null);
  const input2 = useRef(null);
  const input3 = useRef(null);
  const input4 = useRef(null);
  const input5 = useRef(null);
  const input6 = useRef(null);
  const input7 = useRef(null);
  const input8 = useRef(null);
  const input9 = useRef(null);
  const input10 = useRef(null);
  
  const handleButtonClick = () => {
    const refs = [
      input1, input2, input3, input4, input5,
      input6, input7, input8, input9, input10
    ];
    
    const emptyInput = refs.find(ref => 
      ref.current && ref.current.value === ''
    );
    
    if (emptyInput) {
      emptyInput.current.focus();
    }
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input type='text' ref={input1} />
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input type='text' ref={input2} />
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input type='text' ref={input3} />
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input type='text' ref={input4} />
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input type='text' ref={input5} />
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input type='text' ref={input6} />
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input type='text' ref={input7} />
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input type='text' ref={input8} />
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input type='text' ref={input9} />
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input type='text' ref={input10} />
      </div>
      <button type='button' onClick={handleButtonClick}>I'm a button</button>
    </>
  );
}

export default Problem3;